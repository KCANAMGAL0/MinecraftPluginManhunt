package org.manhunt.Utils;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MathUtil{
    public static Location getLocationFromPos(double[] Pos, World world){
        return new Location(world,Pos[0],Pos[1],Pos[2]);
    }

    public static List<Location> getCircle(double Radius, Location MidLocation, double p){
        final double pi = Math.PI;
        Location location = MidLocation;
        double height = MidLocation.getY(),t0 = p*Radius;
        int t = 0;
        List<Location> locations = new ArrayList<>();
        for (double x = 0; x <= (2*pi); x += (pi/t0)){
            t++;
            location = new Location(MidLocation.getWorld(),MidLocation.getX() + Radius * Math.cos(x),height,MidLocation.getZ() + Radius * Math.sin(x));
            locations.add(location);
        }
        return locations;
    }

    public static double getPlaneDistance(Location location1,Location location2){
        if (location1.getWorld().equals(location2.getWorld())){
            return new Location(location1.getWorld(),location1.getX(),0,location1.getZ()).distance(new Location(location2.getWorld(),location2.getX(),0,location2.getZ()));
        }else {
            return 0;
        }
    }
    public static double Keep1DecimalPlace(double a) {
        int b = (int) (a*10);
        return (double) b/10;
    }

    public static double getCosine(double a,double b,double c){
        return (a*a + b*b - c*c) / (2*a*b);
    }

    public static List<Location> getSphere(Location mid, double r, double p, Vector vector){ //p取点密度
        final double pi = Math.PI;
        Location location0;
        World world = mid.getWorld();
        double t0 = p*r,dx,dy,dz,dy2;
        double v1 = Math.acos(vector.getX()),v2 = Math.asin(vector.getZ()),v3 = Math.acos(vector.getY());
        //v1为向量与z轴的夹角 v2是向量与x轴的夹角 v3是向量与y轴的夹角
        List<Location> locations = new ArrayList<>();

        return locations;
    }
}
