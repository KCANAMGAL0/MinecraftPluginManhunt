package org.manhunt.buliding;

import javafx.print.PageLayout;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.manhunt.Main;

import java.util.List;
import java.util.ListResourceBundle;

public class endTower {
    Location location;

    public Location getLocation() {
        return location;
    }

    public double[] getEndTower1Center(){
        double[] endTower1Center = new double[]{0,0,0};
        List<Integer> endTower1 = Main.getPlugin(Main.class).getConfig().getIntegerList("endTower1Center");
        for (int i = 0;i <= endTower1.size() - 1; i++){
            endTower1Center[i] = endTower1.get(i);
        }
        return endTower1Center;
    }

    public double[] getEndTower2Center(){
        double[] endTower2Center = new double[]{0,0,0};
        List<Integer> endTower2 = Main.getPlugin(Main.class).getConfig().getIntegerList("endTower2Center");
        for (int i = 0;i <= endTower2.size() - 1; i++){
            endTower2Center[i] = endTower2.get(i);
        }
        return endTower2Center;
    }

    public Location getEndTowerLocation(double[] a){
        Location location = new Location(Bukkit.getWorld("world"),a[0],a[1],a[2]);
        return location;
    }
}
