package org.manhunt.buliding;

import javafx.print.PageLayout;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.entity.Creeper;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.ExplosionPrimeEvent;
import org.bukkit.potion.PotionEffectType;
import org.manhunt.Utils.MathUtil;
import org.manhunt.game.TheNether;
import org.manhunt.player.playerManager;
import org.manhunt.player.team.MhTeam;

public class protect implements Listener {

    @EventHandler
    public void BlockBreakListener(BlockBreakEvent e){
        SpawnLocation h = new SpawnLocation();
        if (!e.isCancelled()) {
            if (e.getBlock().getWorld().getName().equals("world")) {
                Location location = e.getBlock().getLocation();
                double[] blockPos = new double[]{location.getX(), location.getY(), location.getZ()};
                endTower endT = new endTower();

                if (isProtectBuilding(endT.getEndTower1Center(), blockPos, "B", 16) || isProtectBuilding(endT.getEndTower2Center(), blockPos, "B", 16)) {
                    e.setCancelled(true);
                    e.getPlayer().sendMessage(ChatColor.RED + ChatColor.BOLD.toString() + "你不能在这里破坏方块");
                }

                if (isProtectBuilding(h.getHunterSpawnLocation(), blockPos, "B", 5)) {
                    e.setCancelled(true);
                    e.getPlayer().sendMessage(ChatColor.RED + ChatColor.BOLD.toString() + "你不能在这里破坏方块");
                }

                if (location.distance(TheNether.getMainWorldTeleportLocation()) < 4){
                    e.setCancelled(true);
                    e.getPlayer().sendMessage(ChatColor.RED + ChatColor.BOLD.toString() + "你不能在这里破坏方块");
                }
            } else if (e.getBlock().getWorld().getName().equals("world_the_end")) {
                Location location = e.getBlock().getLocation();
                double[] blockPos = new double[]{location.getX(), location.getY(), location.getZ()};
                if (isProtectBuilding(h.getHunterSpawnTheEndLocation(), blockPos, "B", 6) || isProtectBuilding(h.getRunnerSpawnTheEndLocation(),blockPos,"B",6)) {
                    e.setCancelled(true);
                    e.getPlayer().sendMessage(ChatColor.RED + ChatColor.BOLD.toString() + "你不能在这里破坏方块");
                }
            } else if (e.getBlock().getWorld().getName().equals("world_nether")) {
                Location location = e.getBlock().getLocation();
                if (location.distance(TheNether.getHspawnLocation()) < 4 || location.distance(TheNether.getRspawnLocation()) < 4){
                    e.setCancelled(true);
                    e.getPlayer().sendMessage(ChatColor.RED + ChatColor.BOLD.toString() + "你不能在这里破坏方块");
                }
            }
        }
    }

    @EventHandler
    public void BlockPlaceListener(BlockPlaceEvent e){
        SpawnLocation h = new SpawnLocation();
        if (!e.isCancelled()) {
            if (e.getBlock().getWorld().getName().equals("world")) {
                Location location = e.getBlock().getLocation();
                double[] blockPos = new double[]{location.getX(), location.getY(), location.getZ()};
                endTower endT = new endTower();

                if (isProtectBuilding(endT.getEndTower1Center(), blockPos, "B", 16) || isProtectBuilding(endT.getEndTower2Center(), blockPos, "B", 16)) {
                    e.setCancelled(true);
                    e.getPlayer().sendMessage(ChatColor.RED + ChatColor.BOLD.toString() + "你不能在这里放置方块");
                }
                if (isProtectBuilding(h.getHunterSpawnLocation(), blockPos, "B", 5)) {
                    e.setCancelled(true);
                    e.getPlayer().sendMessage(ChatColor.RED + ChatColor.BOLD.toString() + "你不能在这里放置方块");
                }

                if (location.distance(TheNether.getMainWorldTeleportLocation()) < 4){
                    e.setCancelled(true);
                    e.getPlayer().sendMessage(ChatColor.RED + ChatColor.BOLD.toString() + "你不能在这里放置方块");
                }

            } else if (e.getBlock().getWorld().getName().equals("world_the_end")) {
                Location location = e.getBlock().getLocation();
                double[] blockPos = new double[]{location.getX(), location.getY(), location.getZ()};
                if (isProtectBuilding(h.getHunterSpawnTheEndLocation(), blockPos, "B", 6) || isProtectBuilding(h.getRunnerSpawnTheEndLocation(), blockPos, "B", 6)) {
                    e.setCancelled(true);
                    e.getPlayer().sendMessage(ChatColor.RED + ChatColor.BOLD.toString() + "你不能在这里放置方块");
                }
            } else if (e.getBlock().getWorld().getName().equals("world_nether")) {
                Location location = e.getBlock().getLocation();
                if (location.distance(TheNether.getHspawnLocation()) < 4 || location.distance(TheNether.getRspawnLocation()) < 4){
                    e.setCancelled(true);
                    e.getPlayer().sendMessage(ChatColor.RED + ChatColor.BOLD.toString() + "你不能在这里放置方块");
                }
            }
        }
    }
    @EventHandler
    public void DamageHuntersNearSpawnLocation(EntityDamageByEntityEvent e){
        if (!e.isCancelled() && e.getEntity() instanceof Player) {
            Player player = (Player) e.getEntity();
            if (player.getWorld().getName().equals("world") && getDistance(new double[]{player.getLocation().getX(),player.getLocation().getY(),player.getLocation().getZ()},new SpawnLocation().getHunterSpawnLocation(),"B") <= 10){
                if (new MhTeam().getMhTeam(player).equals("HUNTER")){
                    new playerManager().addEffect(player, PotionEffectType.INCREASE_DAMAGE,3 * 20,0,false);
                    new playerManager().addEffect(player, PotionEffectType.DAMAGE_RESISTANCE,3 * 20,0,false);
                }
            }
        }
    }


    public boolean isProtectBuilding(double[] bulidingPos,double[] blockPos,String mode,int distance){
        if (getDistance(blockPos,bulidingPos,mode) <= distance && blockPos[1] >= 56){
            return true;
        }else return false;
    }

    public double getDistance(double[] a ,double[] b,String mode){
        if (mode.equals("A")){
            double[] c = new double[]{0,0,0};
            for (int i = 0 ;i <= 2; i++){
                c[i] = (a[i] - b[i])*(a[i] - b[i]);
            }
            return Math.sqrt(c[0] + c[1] + c[2]);
        }else if (mode.equals("B")){
            double[] c = new double[]{0,0};
            c[0] = (a[0] - b[0])*(a[0] - b[0]);
            c[1] = (a[2] - b[2])*(a[2] - b[2]);
            return Math.sqrt(c[0] + c[1]);
        } else return 0;
    }

    @EventHandler
    public void a(ExplosionPrimeEvent e){
        if (e.getEntity().getWorld().getName().equals("world")){
            endTower endTower = new endTower();
            if (MathUtil.getPlaneDistance(endTower.getEndTowerLocation(endTower.getEndTower1Center()),e.getEntity().getLocation()) <= 20){
                e.setRadius(0);
            }else if (new SpawnLocation().ArraytoLocation(new SpawnLocation().getHunterSpawnLocation()).distance(e.getEntity().getLocation()) <= 5){
                e.setRadius(0);
            }else if (MathUtil.getPlaneDistance(endTower.getEndTowerLocation(endTower.getEndTower2Center()),e.getEntity().getLocation()) <= 20){
                e.setRadius(0);
            }
        }


    }
    @EventHandler
    public void b(CreatureSpawnEvent e){
        if (e.getEntity() instanceof Creeper || e.getEntity() instanceof TNTPrimed){
            endTower endTower = new endTower();
            if (MathUtil.getPlaneDistance(endTower.getEndTowerLocation(endTower.getEndTower1Center()),e.getEntity().getLocation()) <= 20){
                e.setCancelled(true);
            }else if (new SpawnLocation().ArraytoLocation(new SpawnLocation().getHunterSpawnLocation()).distance(e.getEntity().getLocation()) <= 5){
                e.setCancelled(true);
            }else if (MathUtil.getPlaneDistance(endTower.getEndTowerLocation(endTower.getEndTower2Center()),e.getEntity().getLocation()) <= 20){
                e.setCancelled(true);
            }
        }
    }
}
