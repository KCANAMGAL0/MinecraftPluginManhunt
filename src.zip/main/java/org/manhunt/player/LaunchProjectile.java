package org.manhunt.player;

import org.bukkit.ChatColor;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.manhunt.MhClass.MhClassManager;
import org.manhunt.MhClass.MhClasses;

import java.util.List;

public class LaunchProjectile implements Listener {
    @EventHandler
    public void a(ProjectileLaunchEvent e){
        if (e.getEntity() instanceof Arrow && e.getEntity().getShooter() instanceof Player){
            Arrow arrow = (Arrow) e.getEntity();
            Player player = (Player) arrow.getShooter();
            arrow.setKnockbackStrength(Math.min(arrow.getKnockbackStrength(), 1));
            if (new MhClassManager().getPlayerClass(player).equals(MhClasses.Sac.getName()) && arrow.isCritical()){
                arrow.setFireTicks(Integer.MAX_VALUE);
            }
        }
    }
}
